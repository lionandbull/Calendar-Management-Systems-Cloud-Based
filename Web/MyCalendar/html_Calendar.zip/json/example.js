var data = {
  "name": "private",
  "startdate": "10/01/2018",
  "endDate": "11/01/2019",
  "startHour": "8:00",
  "endHour": "9:00",
  "location": "WPI",
  "days": {}
}


var output - document.getElementById('AvaCalendar');
output.innerHTML = data.name;