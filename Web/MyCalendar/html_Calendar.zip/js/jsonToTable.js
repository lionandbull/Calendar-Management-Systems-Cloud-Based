function jsonToTable(argument) {
	// body...
	console.log("Hello World");
}